



Name: BUNOOTI AGGREY  
Student ID: 2023-U-BCS-MMU-01669  
Date: October 25, 2024  

### Project Title: Cryptographic Algorithms Implementation, Cryptography_Practical_BUNOOTI AGGREY 2023-U-MMU-BCS-01669

### Description:
This project demonstrates the implementation of key cryptographic techniques including RSA encryption, Diffie-Hellman key exchange with AES encryption, hash functions, and digital signatures. Python and its cryptographic libraries were used to ensure efficient and secure encryption and decryption processes.

---

### 1. RSA Encryption (Method I & Method II)

#### Libraries Used:
- **PyCryptodome (`Crypto.Util.number`, `base64`)**: For prime generation, RSA encryption, and encoding data into base64.
- **PyCryptodome (`Crypto.PublicKey.RSA`, `Crypto.Cipher.PKCS1_OAEP`)**: For key generation and encryption using OAEP padding.

#### How It Was Implemented:

##### **Method I**:
- **Key Generation**: Prime numbers `p` and `q` were generated and multiplied to get `n`. The public exponent `e` was set to 65537, and the private key `d` was computed as the modular inverse of `e` modulo the Euler’s Totient function.
- **Encryption**: The message was converted to an integer, encrypted using the formula `ciphertext = (message^e) mod n`, and encoded in base64.
- **Decryption**: The base64 encoded ciphertext was decoded back to integer, and decrypted using `message = (ciphertext^d) mod n`.

##### **Method II**:
- **Key Generation**: RSA key pairs (private and public) were generated using the `RSA.generate(bits)` function with a key size of 2048 bits. The keys were then exported for encryption and decryption purposes.
- **Encryption**: The public key was imported and a cipher was initialized using `PKCS1_OAEP.new()`. The message was encrypted using OAEP padding and then encoded in base64.
- **Decryption**: The private key was imported and a decryption cipher was initialized using `PKCS1_OAEP.new()`. The encrypted message was decoded from base64, and the cipher was used to decrypt it back to the original message.

#### How It Works:
- **RSA Encryption (Method I & II)** is an asymmetric encryption algorithm where the public key is used to encrypt the message and the private key is used to decrypt it. Method I performs basic RSA encryption, while Method II enhances security by using **Optimal Asymmetric Encryption Padding (OAEP)**, a padding scheme designed to prevent certain attacks. Base64 encoding ensures the encrypted message is easily transmitted over text-based communication protocols.

---

### 2. Diffie-Hellman Key Exchange and AES Encryption

#### Libraries Used:
- **PyCryptodome (`Crypto.Cipher.AES`, `Crypto.Util.Padding`)**: Provides AES encryption with CBC mode.
- **random**: Used to generate random private keys for the Diffie-Hellman key exchange.

#### How It Was Implemented:
- **Key Exchange**: Alice and Bob each generate private keys, compute public keys using a generator and prime number, and exchange them. The shared secret is computed by raising the exchanged public key to their own private key.
- **AES Encryption**: The shared secret is hashed using SHA-256 to derive a 16-byte AES key. This key is used in AES encryption with CBC mode to encrypt a message.
- **AES Decryption**: The same AES key is used to decrypt the ciphertext, converting it back into the original message.

#### How It Works:
- **Diffie-Hellman Key Exchange** allows two parties to securely compute a shared secret over an insecure public channel. This secret is used for **AES encryption**, ensuring the confidentiality of the data exchanged between the two parties. AES in CBC mode further secures the data by using an initialization vector (IV) that varies with each encryption.

---

### 3. Hash Functions (SHA-256)

#### Libraries Used:
- **hashlib**: Used to create and verify SHA-256 hashes for message integrity.

#### How It Was Implemented:
- **Hashing**: The input message is encoded and hashed using the `hashlib.sha256()` function. The resulting hash is then used for integrity verification.
- **Hash Verification**: The message is rehashed, and the new hash is compared with the original to verify its integrity.

#### How It Works:
- **SHA-256** is a secure hashing algorithm that generates a fixed-size 256-bit hash value from any input. It is widely used for ensuring data integrity because of its resistance to hash collisions and pre-image attacks. Hash verification ensures that a message has not been tampered with during transmission.

---

### 4. Digital Signatures (ECDSA)

#### Libraries Used:
- **ecdsa**: Used for generating and verifying digital signatures using elliptic curve cryptography.
- **hashlib**: Used to hash the message before signing.

#### How It Was Implemented:
- **Key Generation**: A private and public key pair was generated using the NIST P-384 elliptic curve.
- **Signing**: The message was hashed using SHA-256, and the resulting hash was signed with the private key using ECDSA.
- **Verification**: The public key was used to verify the digital signature against the original hashed message.

#### How It Works:
- **ECDSA (Elliptic Curve Digital Signature Algorithm)** allows for secure signing and verification of messages. A private key is used to sign the message, and the public key is used to verify that the signature is valid. By adding a timestamp to the message, replay attacks are prevented. The combination of elliptic curve cryptography and SHA-256 ensures strong security and high efficiency.

---

### Why These Libraries and Technologies Were Chosen:

- **PyCryptodome**: Provides an efficient and widely-used collection of cryptographic algorithms, including RSA, AES, and hash functions, ensuring secure and optimized implementations.
- **random**: Essential for generating unpredictable private keys for Diffie-Hellman key exchange, enhancing the security of the shared secret.
- **base64**: Encodes binary data into a textual format, allowing for easy transmission of encrypted data over text-based channels.
- **hashlib**: Built-in Python library providing reliable and fast hashing algorithms like SHA-256 for message integrity.
- **ecdsa**: A Python library that implements elliptic curve cryptography for generating secure digital signatures, ensuring message authenticity and integrity.

---

### Usage Instructions:
1. **RSA Encryption (Method I & II)**: Run the script to generate RSA key pairs, encrypt a message using the public key, and decrypt it using the private key.
2. **Diffie-Hellman Key Exchange & AES**: Execute the script to establish a shared secret between two parties and encrypt a message using AES , shared secret key.
3. **SHA-256 Hashing**: Run the hashing script to compute and verify the hash of a message.
4. **Digital Signatures**: Use the ECDSA script to sign a message with a private key and verify the signature using the corresponding public key.

---
  MY PYTHON CODE ARE IN Cryptography_Practical_BUNOOTI AGGREY 2023-U-MMU-BCS-01669
 There is breify doucementation of the code which was written in latex  " DOUCEMENENTATION CRYPTOGRAYP BUNOOTI AGGREY"
This implementation highlights several core cryptographic methods, leveraging Python’s rich library ecosystem to ensure secure and efficient data encryption, integrity verification, and digital signing.
